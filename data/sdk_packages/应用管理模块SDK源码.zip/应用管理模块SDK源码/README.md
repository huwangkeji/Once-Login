# 应用管理模块接入 SDK（应用管理模块SDK源码）

面向「应用管理 / SSO 接入」场景的轻量 SDK 合集，等价于 UIC_SDK 的多语言客户端，
聚焦应用（SP）创建、AppID/Secret 管理、SSO 授权跳转与 Token 交换。

- `src/` `php/` `python/` `js/` `go/` `java/` `c/`   多语言 SDK
- `examples/`   接入示例（快速开始 / 完整用法 / SSO 回调）
- `docs/`       接口文档集
