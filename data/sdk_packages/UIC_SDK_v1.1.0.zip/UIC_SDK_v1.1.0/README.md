# UIC 多语言客户端 SDK 包（UIC_SDK）

提供 PHP / Python / JavaScript / Go / Java / C 六种语言的客户端 SDK，
统一签名鉴权协议（详见 `src/`、`contract.json`）。

- `src/`        PHP PSR-4 源码（Client / AuthClient / UserClient / CaptchaClient）
- `php/`        PHP 单文件零依赖版（UicSdk.php）
- `python/` `js/` `go/` `java/` `c/`   各语言实现
- `examples/`   可运行示例（quickstart / basic_usage / sso_callback / captcha_flow /
                login_code / passkey_flow / admin_products / sso_full_flow）
- `tests/`      单元测试
- `docs/`       接口文档集

安装：Composer `require uic/sdk`，或复制 `sdk/` 目录引入 `vendor/autoload.php`。
