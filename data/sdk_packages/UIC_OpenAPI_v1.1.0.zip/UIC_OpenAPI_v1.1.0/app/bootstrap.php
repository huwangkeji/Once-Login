<?php
/**
 * 引导 / 自动加载 / 全局初始化
 */
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('DATA_PATH', BASE_PATH . '/data');
define('PUBLIC_PATH', BASE_PATH . '/public');
define('UIC_VERSION', '1.0.0');

date_default_timezone_set('Asia/Shanghai');
mb_internal_encoding('UTF-8');

// 简易自动加载：类名 -> 目录同名文件
spl_autoload_register(function ($class) {
    // 命名空间类：lbuchs\WebAuthn\* -> app/Core/WebAuthn/
    if (strpos($class, 'lbuchs\\WebAuthn\\') === 0) {
        $rel  = substr($class, strlen('lbuchs\\WebAuthn\\'));
        $file = APP_PATH . '/Core/WebAuthn/' . str_replace('\\', '/', $rel) . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
        return;
    }
    $map = [
        APP_PATH . '/Core/UCenter/' . $class . '.php',
        APP_PATH . '/Core/Sms/' . $class . '.php',
        APP_PATH . '/Core/' . $class . '.php',
        APP_PATH . '/Model/' . $class . '.php',
        APP_PATH . '/Service/' . $class . '.php',
    ];
    foreach ($map as $f) {
        if (file_exists($f)) {
            require_once $f;
            return;
        }
    }
});

/** 站点根 URL（无 rewrite 场景；settings 表 site_url 优先，其次 config 默认，最后自动推断） */
function site_url($path = '')
{
    $cfgUrl = '';
    try {
        $cfgUrl = (string)Config::get('site_url', '');
    } catch (Exception $e) {
        // 数据库未就绪（安装前 / CLI 场景）时忽略，走 config 默认
    }
    if ($cfgUrl === '') {
        $cfgUrl = (string)(Config::defaults()['site_url'] ?? '');
    }
    if ($cfgUrl !== '') {
        return rtrim($cfgUrl, '/') . '/' . ltrim($path, '/');
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? 80) == 443);
    $scheme = $https ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? '127.0.0.1';
    return $scheme . '://' . $host . '/' . ltrim($path, '/');
}

/** HTML 转义 */
function e($str)
{
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/** 生成随机串（任意长度均精确返回，奇数长度不再截断少一位） */
function rand_str($len = 32)
{
    $len = intval($len);
    if ($len <= 0) {
        return '';
    }
    return substr(bin2hex(random_bytes(intval(($len + 1) / 2))), 0, $len);
}

/** 视图渲染 */
function view($tpl, $vars = [])
{
    $v = $vars;
    extract($vars);
    $file = APP_PATH . '/View/' . $tpl . '.php';
    if (!file_exists($file)) {
        throw new RuntimeException('view not found: ' . $tpl);
    }
    ob_start();
    require $file;
    return ob_get_clean();
}

/** 时间友好格式 */
function human_time($ts)
{
    $ts = intval($ts);
    if (!$ts) {
        return '-';
    }
    $d = time() - $ts;
    if ($d < 60) return $d . ' 秒前';
    if ($d < 3600) return floor($d / 60) . ' 分钟前';
    if ($d < 86400) return floor($d / 3600) . ' 小时前';
    if ($d < 2592000) return floor($d / 86400) . ' 天前';
    return date('Y-m-d H:i', $ts);
}

/** 站点名称（全局可用，从配置读取） */
function site_name()
{
    return Config::get('site_name', '统一身份认证中心');
}

// 企业级：全局安全响应头（CSP / X-Frame-Options 等；CLI 自检场景自动跳过）
SecureHeaders::send();
