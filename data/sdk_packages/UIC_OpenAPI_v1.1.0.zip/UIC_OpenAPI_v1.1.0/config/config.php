<?php
/**
 * 全局配置文件
 * 真实部署修改此文件即可，MySQL 中的 settings 表优先级更高（可覆盖本文件大部分值）。
 */

$__db_default = [
    'host'    => '127.0.0.1',
    'port'    => 3306,
    'dbname'  => 'uic_auth',
    'user'    => 'uic_app',
    'pass'    => '',
    'charset' => 'utf8mb4',
    'prefix'  => '',                 // 表前缀，如 'uic_'；留空则不加前缀
];
// 数据库凭据独立存放于 data/db_cred.php（不在 web 可读目录、不参与版本管理）
$__db_cred_file = __DIR__ . '/../data/db_cred.php';
if (is_file($__db_cred_file)) {
    $__loaded = require $__db_cred_file;
    if (is_array($__loaded)) {
        $__db_default = array_merge($__db_default, $__loaded);
    }
}

return [
    // ---------- 运行模式 ----------
    'debug'      => false,
    'timezone'   => 'Asia/Shanghai',
    // ---------- 数据库（MySQL）----------
    // 连接参数可被 data/db_cred.php 覆盖；schema 路径保留供迁移/恢复工具使用
    'db'          => $__db_default,
    'schema_path' => __DIR__ . '/../data/schema.sql',

    // ---------- 站点 ----------
    'site_name'   => '统一身份认证中心',
    'site_slogan' => '一次登录，处处通行',
    'site_url'    => '',   // 站点根地址，留空自动推断；如需固定可在后台系统设置填写

    // ---------- 站点信息（备案 / 联系方式 / 底部信息，settings 表可覆盖）----------
    'site_company'       => '沧州氢境科技有限公司',       // 主体/公司名称
    'site_icp'           => '',                          // ICP 备案号，如：京ICP备12345678号
    'site_icp_link'      => 'https://beian.miit.gov.cn/',// 备案查询跳转地址
    'site_police'        => '',                          // 公安联网备案号，如：京公网安备11010802012345号
    'site_police_link'   => '',                          // 公安备案查询地址
    'site_contact_email' => '',                          // 对外联系邮箱
    'site_contact_phone' => '',                          // 对外联系电话
    'site_contact_url'   => '',                          // 在线客服/工单地址
    'site_footer_text'   => '',                          // 底部自定义文案（纯文本）
    'site_footer_html'   => '',                          // 底部额外 HTML（如统计代码，需可信）
    'site_copyright'     => '',                          // 版权声明，留空自动生成
    'site_logo'          => '',                          // 站点 Logo 地址，留空用默认 U 标

    // ---------- UCenter ----------
    'ucenter' => [
        'enabled'  => true,
        'driver'   => 'mock',              // http = 真实 UCenter | mock = 本地模拟
        'url'      => 'http://127.0.0.2/uc_server',
        'ip'       => '',
        // 通信密钥：安装时由 install.php 自动生成随机值写入 settings 表（uc_key）并优先读取；
        // 此处留空可避免把默认密钥带入生产。对接真实 UCenter 时也须保证两端完全一致。
        'key'      => '',
        'appid'    => 2,
        'connect'  => 'post',
        'charset'  => 'utf-8',
        'timeout'  => 10,
    ],

    // ---------- SSO ----------
    'sso' => [
        'session_ttl'   => 7200,    // 普通会话 2 小时
        'remember_ttl'  => 2592000, // 记住登录 30 天
        'ticket_ttl'    => 60,      // Ticket 60 秒
        'token_ttl'     => 604800,  // Token 7 天
        'cookie_name'   => 'uic_sid',
        'remember_name' => 'uic_rid',
    ],

    // ---------- 安全 ----------
    'security' => [
        'login_fail_limit' => 5,
        'login_lock_time'  => 900,
        'pwd_min_length'   => 6,
        'pwd_max_length'   => 32,
        'captcha_login'    => false,
    ],

    // ---------- 短信验证码网关（settings 表可覆盖）----------
    // 可插拔架构：服务商实现见 app/Core/Sms/，新增无需改动此处与发送逻辑
    'sms_enabled'    => false,      // 短信发送总开关
    'sms_provider'   => '',         // 主服务商：tencent / smsbao / aliyun / huawei，空=未接入(调试模式)
    'sms_code_style' => 'digits',   // digits 纯数字6位 / letters 纯字母4位 / mixed 数字+字母4位
    'sms_strategy'   => 'failover', // failover 故障自动切换 / priority 优先级 / roundrobin 轮询

    // 公共配置（与具体服务商无关）：验证码有效期、发送频率限制、模板变量等
    // 缺省值见 SmsGateway::commonFields()
    'sms_common'     => [
        'code_ttl'       => 600,    // 验证码有效期（秒）
        'send_interval'  => 60,     // 同一手机号发送间隔（秒）
        'daily_limit'    => 10,     // 同一手机号每日上限
        'ip_daily_limit' => 30,     // 同一 IP 每日上限
        'template_var'   => 'code', // 模板变量名
        'strategy'       => 'failover',
    ],

    // 各服务商私有配置（JSON）：{ provider => { enabled, priority, 各服务商自有字段 } }
    // 密钥等敏感字段可留空，改由环境变量注入：UIC_SMS_{服务商}_{字段}（全大写）
    // 例：UIC_SMS_TENCENT_SECRET_ID=xxx  UIC_SMS_ALIYUN_ACCESS_KEY_SECRET=xxx
    'sms_providers'  => [],

    // ---------- 图形验证码（人机验证，后台/前台登录、找回密码）----------
    'login_captcha'  => true,               // 登录等敏感操作显示图形验证码
    'admin_login_captcha' => true,          // 后台登录图形验证码（独立开关，后台「系统设置」可自行打开/关闭）

    // ---------- 管理员找回密码（后台登录页「忘记密码？」）----------
    'admin_findpwd_enabled' => 1,           // 管理员邮件验证码自助重置总开关（还需开启邮件服务且该管理员已设置邮箱）
    'admin_findpwd_debug'   => 0,           // 回显验证码（需同时开启 debug）；生产严禁开启，否则存在后台被接管风险
    'captcha_style'  => 'slide',            // slide 滑动拼图 / click 文字点选 / icon 图标选择 / passive 无感验证 / digits 纯数字 / mixed 数字+字母
    'captcha_fallback' => 'slide',          // 无感验证未通过时自动回退的交互式验证码（slide/click/icon/digits/mixed）

    // ---------- 无感验证（行为式风险识别引擎，参考极验 / 腾讯天御 / Cloudflare）----------
    // 全部可在后台「设置中心 → 安全与验证 → 无感验证」调整；settings 表优先级更高
    'passive_enabled'        => 1,         // 无感风险引擎总开关（0=回退旧版简单阈值）
    'passive_trigger'        => 'always',   // always 始终评分 / suspicious 仅可疑流量评分
    'passive_verify_intensity' => 'normal', // low 宽松 / normal 默认 / strict 严格 / custom 自定义
    'passive_score_pass'     => 35,         // 风险分 ≤ 此值：无感放行（0-100）
    'passive_score_challenge' => 70,        // 风险分 ≤ 此值：降级交互式验证；超出拦截
    'passive_score_block'    => 88,         // 风险分 > 此值：直接拦截
    'passive_w_behavior'     => 60,         // 行为信号权重 %
    'passive_w_env'          => 20,         // 环境信号权重 %
    'passive_w_server'       => 20,         // 服务端信号权重 %
    'passive_allowlist'      => '',         // 放行白名单（精确 IP / 通配 / CIDR）
    'passive_collect_ms'     => 1600,       // 前端轨迹采集窗口 ms
    'passive_max_points'     => 120,        // 轨迹最大采样点
    'passive_trust_ttl'      => 3600,       // 信任凭证有效期 s
    'passive_secret'         => '',         // 信任凭证 HMAC 密钥（留空用安装级默认值）

    // ---------- 验证码登录（邮箱 / 手机号）----------
    // 独立开关：可单独开启/关闭邮箱或手机号验证码登录，密码登录不受影响
    'login_code_enabled'       => 1,   // 验证码登录总开关（0=关闭 1=开启）
    'login_code_email_enabled' => 1,   // 邮箱验证码登录（0=关闭 1=开启）
    'login_code_sms_enabled'   => 0,   // 手机号验证码登录（0=关闭 1=开启）
    'login_code_ttl'           => 300, // 登录验证码有效期（秒），默认 5 分钟
    'login_code_interval'      => 60,  // 同一目标发送间隔（秒）

    // ---------- 通行密钥 / WebAuthn（settings 表可覆盖）----------
    // WebAuthn 仅在安全上下文（HTTPS 或 127.0.0.1/localhost）下可用
    'passkey_enabled'        => 0,          // 总开关（0=关闭 1=开启）
    'passkey_rp_id'          => '',         // RP ID（域名），留空自动从 site_url 推导
    'passkey_rp_name'        => '',         // RP 显示名称，留空用 site_name
    'passkey_uv'             => 'preferred', // 用户验证要求：required / preferred / discouraged
    'passkey_timeout'        => 120,        // 超时秒数
    'passkey_max_per_user'   => 10,         // 每用户最大通行密钥数
];