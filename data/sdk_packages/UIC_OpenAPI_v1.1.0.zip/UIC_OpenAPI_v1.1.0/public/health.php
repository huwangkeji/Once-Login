<?php
/**
 * 健康检查端点（运维探活 / 负载均衡探测）
 *
 * 用法：GET /health.php
 * 返回：JSON（200 = 全部正常；503 = degraded）
 *   {
 *     "status": "ok|degraded",
 *     "service": "uic-auth-center",
 *     "version": "1.0.0",
 *     "time": "...",
 *     "checks": { "database": "ok", "ucenter": "ok" }
 *   }
 *
 * 安全：无敏感信息、无登录要求、禁止缓存；仅做轻量可达性探测。
 */
require_once dirname(__DIR__) . '/app/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$dbOk = true;
try {
    Database::getInstance()->val('SELECT 1');
} catch (Exception $e) {
    $dbOk = false;
}

$ucOk = false;
try {
    $ping = (new UCenterClient())->ping();
    $ucOk = !empty($ping['ok']);
} catch (Exception $e) {
    $ucOk = false;
}

$ok = $dbOk && $ucOk;
http_response_code($ok ? 200 : 503);
echo json_encode([
    'status'  => $ok ? 'ok' : 'degraded',
    'service' => 'uic-auth-center',
    'version' => UIC_VERSION,
    'time'    => date('c'),
    'checks'  => [
        'database' => $dbOk ? 'ok' : 'error',
        'ucenter'  => $ucOk ? 'ok' : 'error',
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);