# UIC 开放平台 · 完整源码包（UIC_OpenAPI）

本包包含统一身份认证中心（UIC）的完整可部署源码：

- `app/`        应用核心（Controller / Service / Model / View）
- `public/`     Web 根目录（唯一对外暴露目录，含 api/uc.php 等入口）
- `config/`     全局配置样例
- `sdk/`        多语言客户端 SDK 源码
- `docs.php`    在线开发者文档入口

文档见 `docs/`，接入示例见 `examples/`（与 `sdk/examples/` 一致）。
部署：首次访问 `public/install.php` 完成初始化（生成管理员、写入 data/install.lock）。
